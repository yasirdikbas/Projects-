#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <string.h>
#include "add.h"

int *
add_1_svc(numbers *argp, struct svc_req *rqstp)
{
	static int  result = -1;

	printf("Got request: adding %d and %d\n",argp->a,argp->b);
	
	int     p2c[2], c2p[2];
    pid_t   pid;
    char    w_buf[200], r_buf[10000];

    /**
     * The parent creates the pipes, which will be attached to stdin, stdout, and stderr or the child.
     */
    pipe(p2c);
    pipe(c2p);

    if((pid=fork()) == -1) {
        fprintf(stderr, "fork() failed.\n");
        exit(-1);
    }

    //.......................................................................................................
    if(pid > 0) {
        /**
         * This is the code for the parent process.
         */
        char line[1000];
        int nbytes;

        /**
         * The parent should close the ends of the pipes that it will not use.
         */
        close(p2c[0]);    // Parent will not read from p2c
        close(c2p[1]);    // Parent will not write to c2p

        /**
         * Now, send the name of the directory for which you want to run the "ls" command 
         * through the reverse pipe(c2p).
         * Note that the '\n' is required in the string so that the child can read with scanf().
         */



        sprintf(w_buf, "%d %d\n",argp->a,argp->b);
        write(p2c[1], w_buf, strlen(w_buf));

        /**
         * Capture the output of the child process (execution of "ls" program) and display on the screen.
         */
        nbytes = read(c2p[0], r_buf, sizeof(r_buf));
        if(strlen(r_buf)>2 && atoi(r_buf) == 0)
			result = -1;
		else
			result = atoi(r_buf);

    }
    //.......................................................................................................
    else {
        /**
         * This is the code for the child process.
         */
		
        /**
         * The child associates the read end of forward pipe (p2c) with its own stdin.
         */
        dup2(p2c[0], STDIN_FILENO);

        /**
         * The child associates the write end of reverse pipe (c2p) with its own stdout and stderr.
         */
        dup2(c2p[1], STDOUT_FILENO);
        dup2(c2p[1], STDERR_FILENO);

        /**
         * The child can close all pipes since they are not needed anymore. Nothing will happen to stdin, stdout, stderr.
         */
        close(c2p[0]);
        close(c2p[1]);
        close(p2c[0]);
        close(p2c[1]);
        /**
         * If you want to try capturing the output of an external program 
         * (even a program that you don't have access to the source code),
         * comment out the printf() statement above and uncomment execl() below.
         */
        execl("blackbox", "blackbox", NULL);

    }

	return &result;
}