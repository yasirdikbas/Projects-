/* We must run this query with this order because we must delete first tables
	that contains Forign Keys then drop those with Primary keys */
-- To Use master database engine
USE SimpleBounDB
GO
-- DROP TABLES
DROP TABLE [dbo].[Added_Courses]
GO
DROP TABLE [dbo].[Prerequisites]
GO
DROP TABLE [dbo].[Database_Manager]
GO
DROP TABLE [dbo].[Grades]
GO
DROP TABLE [dbo].[Courses]
GO
DROP TABLE [dbo].[Instructors]
GO
DROP TABLE [dbo].[Students]
GO
DROP TABLE [dbo].[Departments]
GO
DROP TABLE [dbo].[Classrooms]
GO

-- to drop database by forse
/* Dropping a database deletes the database from an instance of SQL Server
	and deletes the physical disk files used by the database. If the database 
	or any one of its files is offline when it is dropped, the disk files are not deleted.
	These files can be deleted manually by using Windows Explorer. To remove a database 
	from the current server without deleting the files from the file system, use sp_detach_db.*/

USE master
GO
ALTER DATABASE [SimpleBounDB] SET SINGLE_USER WITH ROLLBACK IMMEDIATE
GO
DROP DATABASE [SimpleBounDB]
GO